﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PDespesa0030482311031
{
    internal class tipo
    {
        private int idTipo;
        private string descricaoTipo;

        public int IDTipo
        {
            get
            {
                return idTipo;
            }
            set
            {
                idTipo = value;
            }
        }

        public DataTable Listar()
        {
            SqlDataAdapter daTipo;

            DataTable dtTipo = new DataTable();

            try
            {
                daTipo = new SqlDataAdapter("SELECT * FROM TIPO", frmPrincipal.conexao);
                daTipo.Fill(dtTipo);
                daTipo.FillSchema(dtTipo, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtTipo;
        }
    }
}
