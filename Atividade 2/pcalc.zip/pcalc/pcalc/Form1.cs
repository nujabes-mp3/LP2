﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;

        private void Brnsair_Validated(object sender, EventArgs e)
        {

        }

        private void Txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                MessageBox.Show("Número inválido!");
                txtnumero1.Focus();
            }
        }

        private void Txtnumero2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero2.Text, out numero2))
            {
                MessageBox.Show("Número inválido!");
                txtnumero2.Focus();
            }
        }

        private void Btnmais_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void Btnmenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void Btnvezes_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            resultado = numero1 / numero2;
            txtresultado.Text = resultado.ToString();
            if (numero2 == 0)
            { MessageBox.Show("Não se pode dividir por zero!!", "Muito burro, filho!",
            MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnumero2.Focus();
            }

            else
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString();
            }
        }

        private void Brnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo da calculadora do Kanye West?", "Diga tchau pro Ye", MessageBoxButtons.YesNo, MessageBoxIcon.Question)==
                DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
            txtnumero1.Focus();
            resultado = 0;
            
        }
    }
}
