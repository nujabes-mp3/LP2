﻿namespace pcalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.brnsair = new System.Windows.Forms.Button();
            this.btnmais = new System.Windows.Forms.Button();
            this.lblnumero1 = new System.Windows.Forms.Label();
            this.lblnumero2 = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.txtnumero1 = new System.Windows.Forms.TextBox();
            this.txtnumero2 = new System.Windows.Forms.TextBox();
            this.txtresultado = new System.Windows.Forms.TextBox();
            this.lbltitulo = new System.Windows.Forms.Label();
            this.btndiv = new System.Windows.Forms.Button();
            this.btnvezes = new System.Windows.Forms.Button();
            this.btnmenos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2765, 395);
            this.button1.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(660, 263);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnlimpar
            // 
            this.btnlimpar.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnlimpar.Location = new System.Drawing.Point(1093, 154);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(216, 91);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.Btnlimpar_Click);
            // 
            // brnsair
            // 
            this.brnsair.ForeColor = System.Drawing.Color.Fuchsia;
            this.brnsair.Location = new System.Drawing.Point(1093, 307);
            this.brnsair.Name = "brnsair";
            this.brnsair.Size = new System.Drawing.Size(216, 89);
            this.brnsair.TabIndex = 2;
            this.brnsair.Text = "sair";
            this.brnsair.UseVisualStyleBackColor = true;
            this.brnsair.Click += new System.EventHandler(this.Brnsair_Click);
            this.brnsair.Validated += new System.EventHandler(this.Brnsair_Validated);
            // 
            // btnmais
            // 
            this.btnmais.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnmais.BackgroundImage")));
            this.btnmais.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmais.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnmais.Location = new System.Drawing.Point(292, 497);
            this.btnmais.Name = "btnmais";
            this.btnmais.Size = new System.Drawing.Size(144, 123);
            this.btnmais.TabIndex = 6;
            this.btnmais.Text = "+";
            this.btnmais.UseVisualStyleBackColor = true;
            this.btnmais.Click += new System.EventHandler(this.Btnmais_Click);
            // 
            // lblnumero1
            // 
            this.lblnumero1.AutoSize = true;
            this.lblnumero1.BackColor = System.Drawing.Color.Transparent;
            this.lblnumero1.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblnumero1.Location = new System.Drawing.Point(148, 154);
            this.lblnumero1.Name = "lblnumero1";
            this.lblnumero1.Size = new System.Drawing.Size(243, 38);
            this.lblnumero1.TabIndex = 7;
            this.lblnumero1.Text = "Insira um número:";
            // 
            // lblnumero2
            // 
            this.lblnumero2.AutoSize = true;
            this.lblnumero2.BackColor = System.Drawing.Color.Transparent;
            this.lblnumero2.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblnumero2.Location = new System.Drawing.Point(148, 255);
            this.lblnumero2.Name = "lblnumero2";
            this.lblnumero2.Size = new System.Drawing.Size(243, 38);
            this.lblnumero2.TabIndex = 8;
            this.lblnumero2.Text = "Insira um número:";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.BackColor = System.Drawing.Color.Transparent;
            this.lblresultado.ForeColor = System.Drawing.Color.Fuchsia;
            this.lblresultado.Location = new System.Drawing.Point(148, 381);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(149, 38);
            this.lblresultado.TabIndex = 9;
            this.lblresultado.Text = "Resultado:";
            // 
            // txtnumero1
            // 
            this.txtnumero1.Location = new System.Drawing.Point(460, 154);
            this.txtnumero1.Name = "txtnumero1";
            this.txtnumero1.Size = new System.Drawing.Size(556, 45);
            this.txtnumero1.TabIndex = 10;
            this.txtnumero1.Validated += new System.EventHandler(this.Txtnumero1_Validated);
            // 
            // txtnumero2
            // 
            this.txtnumero2.Location = new System.Drawing.Point(460, 267);
            this.txtnumero2.Name = "txtnumero2";
            this.txtnumero2.Size = new System.Drawing.Size(556, 45);
            this.txtnumero2.TabIndex = 11;
            this.txtnumero2.Validated += new System.EventHandler(this.Txtnumero2_Validated);
            // 
            // txtresultado
            // 
            this.txtresultado.BackColor = System.Drawing.SystemColors.Control;
            this.txtresultado.Enabled = false;
            this.txtresultado.Location = new System.Drawing.Point(460, 381);
            this.txtresultado.Name = "txtresultado";
            this.txtresultado.Size = new System.Drawing.Size(556, 45);
            this.txtresultado.TabIndex = 12;
            // 
            // lbltitulo
            // 
            this.lbltitulo.AutoSize = true;
            this.lbltitulo.BackColor = System.Drawing.Color.Transparent;
            this.lbltitulo.Font = new System.Drawing.Font("Comic Sans MS", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltitulo.ForeColor = System.Drawing.Color.Fuchsia;
            this.lbltitulo.Location = new System.Drawing.Point(392, 50);
            this.lbltitulo.Name = "lbltitulo";
            this.lbltitulo.Size = new System.Drawing.Size(736, 101);
            this.lbltitulo.TabIndex = 13;
            this.lbltitulo.Text = "Kanye West Calculator ";
            this.lbltitulo.UseCompatibleTextRendering = true;
            // 
            // btndiv
            // 
            this.btndiv.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btndiv.BackgroundImage")));
            this.btndiv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btndiv.ForeColor = System.Drawing.Color.Fuchsia;
            this.btndiv.Location = new System.Drawing.Point(1043, 497);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(144, 123);
            this.btndiv.TabIndex = 14;
            this.btndiv.Text = "/";
            this.btndiv.UseVisualStyleBackColor = true;
            this.btndiv.Click += new System.EventHandler(this.Btndiv_Click);
            // 
            // btnvezes
            // 
            this.btnvezes.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnvezes.BackgroundImage")));
            this.btnvezes.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnvezes.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnvezes.Location = new System.Drawing.Point(801, 497);
            this.btnvezes.Name = "btnvezes";
            this.btnvezes.Size = new System.Drawing.Size(144, 123);
            this.btnvezes.TabIndex = 15;
            this.btnvezes.Text = "*";
            this.btnvezes.UseVisualStyleBackColor = true;
            this.btnvezes.Click += new System.EventHandler(this.Btnvezes_Click);
            // 
            // btnmenos
            // 
            this.btnmenos.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnmenos.BackgroundImage")));
            this.btnmenos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnmenos.ForeColor = System.Drawing.Color.Fuchsia;
            this.btnmenos.Location = new System.Drawing.Point(537, 497);
            this.btnmenos.Name = "btnmenos";
            this.btnmenos.Size = new System.Drawing.Size(144, 123);
            this.btnmenos.TabIndex = 16;
            this.btnmenos.Text = "-";
            this.btnmenos.UseVisualStyleBackColor = true;
            this.btnmenos.Click += new System.EventHandler(this.Btnmenos_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 38F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1472, 779);
            this.Controls.Add(this.btnmenos);
            this.Controls.Add(this.btnvezes);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.lbltitulo);
            this.Controls.Add(this.txtresultado);
            this.Controls.Add(this.txtnumero2);
            this.Controls.Add(this.txtnumero1);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lblnumero2);
            this.Controls.Add(this.lblnumero1);
            this.Controls.Add(this.btnmais);
            this.Controls.Add(this.brnsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Comic Sans MS", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button brnsair;
        private System.Windows.Forms.Label lblnumero1;
        private System.Windows.Forms.Label lblnumero2;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.TextBox txtnumero1;
        private System.Windows.Forms.TextBox txtnumero2;
        private System.Windows.Forms.TextBox txtresultado;
        private System.Windows.Forms.Label lbltitulo;
        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btnvezes;
        private System.Windows.Forms.Button btnmenos;
        private System.Windows.Forms.Button btnmais;
    }
}

